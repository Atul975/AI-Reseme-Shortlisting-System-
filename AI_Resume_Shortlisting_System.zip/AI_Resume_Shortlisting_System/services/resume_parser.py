"""Text extraction for supported PDF and DOCX resume files."""

from pathlib import Path

def extract_text(file_path):
    extension = Path(file_path).suffix.lower()

    if extension == ".pdf":
        from pypdf import PdfReader
        reader = PdfReader(file_path)
        return "\n".join(page.extract_text() or "" for page in reader.pages)

    if extension == ".docx":
        from docx import Document
        document = Document(file_path)
        return "\n".join(paragraph.text for paragraph in document.paragraphs)

    raise ValueError("Unsupported file type. Use PDF or DOCX.")
