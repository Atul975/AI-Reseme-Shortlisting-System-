"""Baseline text matching using TF-IDF and cosine similarity.

This is a simple lexical similarity baseline, not a measure of candidate quality.
"""

import re
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

def clean_text(text):
    text = text.lower()
    text = re.sub(r"\s+", " ", text)
    return text.strip()

def rank_resumes(job_description, resumes):
    if not job_description.strip():
        raise ValueError("The job description is empty.")
    if not resumes:
        raise ValueError("No readable resume text was found.")

    documents = [clean_text(job_description)] + [clean_text(item["text"]) for item in resumes]
    vectorizer = TfidfVectorizer(stop_words="english")
    matrix = vectorizer.fit_transform(documents)
    scores = cosine_similarity(matrix[0:1], matrix[1:]).flatten()

    results = []
    for item, score in zip(resumes, scores):
        results.append({
            "filename": item["filename"],
            "score": round(float(score) * 100, 2),
            "note": "Text similarity only; review the resume manually."
        })

    return sorted(results, key=lambda row: row["score"], reverse=True)
