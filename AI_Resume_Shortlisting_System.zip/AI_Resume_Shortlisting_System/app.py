from flask import Flask, render_template, request
from werkzeug.utils import secure_filename
from services.resume_parser import extract_text
from services.matcher import rank_resumes
import os
import uuid

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 10 * 1024 * 1024  # 10 MB per request
app.config["UPLOAD_FOLDER"] = os.path.join("uploads")
ALLOWED_EXTENSIONS = {"pdf", "docx"}

os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route("/", methods=["GET", "POST"])
def index():
    results = []
    error = None
    job_description = ""

    if request.method == "POST":
        job_description = request.form.get("job_description", "").strip()
        uploaded_files = request.files.getlist("resumes")

        if not job_description:
            error = "Please enter a job description."
        elif not uploaded_files or all(not f.filename for f in uploaded_files):
            error = "Please upload at least one PDF or DOCX resume."
        else:
            parsed_resumes = []
            for file in uploaded_files:
                if not file or not file.filename:
                    continue
                if not allowed_file(file.filename):
                    error = "Only PDF and DOCX files are supported."
                    break

                safe_name = secure_filename(file.filename)
                unique_name = f"{uuid.uuid4().hex}_{safe_name}"
                saved_path = os.path.join(app.config["UPLOAD_FOLDER"], unique_name)
                file.save(saved_path)
                try:
                    text = extract_text(saved_path)
                    if text.strip():
                        parsed_resumes.append({"filename": safe_name, "text": text})
                    else:
                        error = f"Could not extract readable text from {safe_name}. It may be scanned or image-based."
                        break
                except Exception:
                    error = f"Unable to read {safe_name}. Please check that the file is a valid PDF or DOCX."
                    break
                finally:
                    try:
                        os.remove(saved_path)
                    except OSError:
                        pass

            if not error:
                try:
                    results = rank_resumes(job_description, parsed_resumes)
                except ValueError as exc:
                    error = str(exc)

    return render_template("index.html", results=results, error=error, job_description=job_description)

@app.errorhandler(413)
def too_large(_error):
    return "Upload too large. Please keep the total request under 10 MB.", 413

if __name__ == "__main__":
    app.run(debug=True)
