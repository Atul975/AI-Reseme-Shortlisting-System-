# AI-Powered Resume Shortlisting System

An **early academic prototype** based on the scope described in the supplied Interim Project Report-I. It is intentionally limited to the initial workflow and does not include advanced semantic models, generative-AI explanations, production deployment, or a validated hiring model.

## Included in this ZIP
- Flask web page for entering a job description and uploading multiple resumes.
- Text extraction from text-based PDF and DOCX files.
- Basic text cleanup.
- TF-IDF feature representation and cosine-similarity scores.
- Candidate ordering by text-similarity score.
- A simple results table and human-review warning.

## Not included
- OCR for scanned/image-only resumes.
- Advanced semantic embeddings or a trained ML ranking model.
- GenAI-generated candidate analysis.
- Authentication, database, cloud deployment, or recruiter account management.
- Validated performance/fairness results or a claim that this system is ready for real hiring.

## Run locally
Use Python 3.10 or newer.

1. Extract the ZIP.
2. Open a terminal in the extracted `AI_Resume_Shortlisting_System` folder.
3. Create and activate a virtual environment:

   Windows:
   ```bash
   python -m venv .venv
   .venv\\Scripts\\activate
   ```

   macOS/Linux:
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   ```

4. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

5. Start the app:
   ```bash
   python app.py
   ```

6. Open `http://127.0.0.1:5000` in your browser.

## Important limitations
- The similarity score reflects overlap in text, not a person's ability or overall suitability.
- Formatting, missing text, synonyms, and context can affect scores.
- Do not make hiring decisions from the score alone. A human reviewer must inspect the resumes.
- Uploaded files are saved temporarily for extraction and then deleted by the app, but this is not a security-audited system. Use only sample/test resumes until proper privacy and security controls are added.

## Suggested next development steps
1. Add tests for PDF/DOCX parsing and matching.
2. Improve extraction and handle malformed files more clearly.
3. Display matched terms to make results easier to inspect.
4. Evaluate on appropriately labeled sample data and document limitations.
5. Consider semantic matching only after establishing a baseline and evaluation method.
